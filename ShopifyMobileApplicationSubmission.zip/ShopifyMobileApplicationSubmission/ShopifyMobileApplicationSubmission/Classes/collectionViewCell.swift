//
//  collectionViewCell.swift
//  ShopifyMobileApplicationSubmission
//
//  Created by Admin on 2019-01-13.
//  Copyright © 2019 Guneet SIngh Lamba. All rights reserved.
//

import UIKit

class collectionViewCell: UICollectionViewCell {
    @IBOutlet weak var ProductImage: UIImageView!
    @IBOutlet weak var ProductLabel: UILabel!
    
}
